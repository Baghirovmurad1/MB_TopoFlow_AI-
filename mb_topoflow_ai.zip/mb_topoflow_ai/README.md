# MB TopoFlow AI (Skeleton)

This repository contains a **minimal skeleton** for the MB TopoFlow AI project.  
The goal of the project is to build an AI‑assisted pipeline for repairing and analysing 3D meshes using advanced mathematics, such as discrete Ricci flow and topological surgery, along with machine‑learning modules for defect detection and correction.

## Directory structure

```
mb_topoflow_ai/
├── README.md            # this file
├── .gitignore           # common ignore rules
├── packages/
│   └── topo-core/       # core Python package for Ricci flow and mesh operations
│       ├── requirements.txt
│       ├── src/topocore/
│       │   ├── __init__.py
│       │   └── ricci.py
│       └── pyproject.toml
├── tests/
│   └── test_ricci.py    # basic unit test for the Ricci step
└── .github/workflows/ci.yml  # GitHub Actions configuration for running tests
```

## Quick start

1. Create a virtual environment and install dependencies:

   ```sh
   cd packages/topo-core
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. Run the unit tests:

   ```sh
   pytest -q
   ```

This scaffold provides a starting point for further development.  
Replace the placeholder Ricci flow implementation in `ricci.py` with a proper discrete solver and extend the codebase with modules for mesh loading, anomaly detection, and topological surgery as described in the project documentation.