# MB TopoFlow AI

This repository contains a **curated, GitHub-ready** selection of the most complete files from multiple project archives.

## Folders
- `src/topocore/` — minimal core (Ricci Flow placeholder) + tests.
- `docs/` — whitepaper(s), analysis, advanced geometric pipeline.
- `planning/` — 30/60/90-Day Plan, Strategic Roadmap.
- `product/` — Financial & Technical Roadmap + Business Pitch, Professional Description.
- `agents/` — reserved for prompt packs and agent configs (to be added).
- `assets/` — images/logos.
- `samples/` — sample data (to be added).

> Note: This is a curated subset focused on the **most refined** versions found. A machine-readable provenance list is in `_selected_sources.json`.
