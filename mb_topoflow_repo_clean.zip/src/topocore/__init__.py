"""Source code for the MB TopoFlow AI prototype.

Modules:
    mesh      – mesh representation and I/O
    analyzer  – topology analysis utilities
    ricci_flow– smoothing algorithms
    surgery   – topological repair operations
    cli       – command‑line interface
"""
