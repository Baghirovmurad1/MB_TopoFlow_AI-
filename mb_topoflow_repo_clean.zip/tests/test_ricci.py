"""Unit tests for the placeholder Ricci flow implementation."""

import numpy as np
from packages.topo_core.src.topocore.ricci import RicciState, ricci_step


def test_ricci_step_moves_u_towards_target():
    """Conformal factors should move opposite to the curvature sign."""
    # Example curvature values (per vertex)
    K = np.array([0.5, -0.25, 0.1], dtype=float)
    # Initial conformal factors set to zero
    u0 = np.zeros_like(K)
    # Choose a small time step
    tau = 0.1
    # Create state
    state0 = RicciState(K=K, u=u0, tau=tau)
    # Perform one Ricci step
    state1 = ricci_step(state0, K_target=0.0)
    # The update to u should be negative of K times tau
    expected_u = u0 - tau * K
    assert np.allclose(state1.u, expected_u)